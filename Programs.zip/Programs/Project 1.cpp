#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<fstream>

using namespace std;

int main()
{
    int n,s,t;
    while(true)
    {
        cout<<"1. Sort "<<endl;
        cin>>n;
        cout<<endl;
        switch(n)
        {
        case 1:
            {
                cout<<"1. Insertion sort\n2. Goto main menu\n3. exit program"<<endl;
                cin>>s;
                switch(s)
                {
                case 1:
                    {
                        cout<<"How many data you want to sort??"<<endl;
                        cin>>t;
                        int arr[t];
                        int key,j;
                        for(int i=0; i<t; i++)
                        {
                            arr[i] = rand() % 100;
                            cout<<arr[i]<<" ";
                        }
                        cout<<"\nSorting..."<<endl;
                        for(int i=1; i<t; i++)
                        {
                            key = arr[i];
                            j=i;
                            while(j>0 && arr[j-1]>key)
                            {
                                arr[j] = arr[j-1];
                                j--;
                            }
                            arr[j] = key;
                        }
                        for(int i=0; i<t; i++)
                        {
                            cout<<arr[i]<<" ";
                        }
                        cout<<"\n\n";
                        break;
                    }
                case 2:
                    {
                        cout<<endl<<endl;
                        break;
                    }
                case 3:
                    {
                        goto out;
                    }
                default:
                    {
                        cout<<"Please enter correct number.\n\n"<<endl;
                    }
                }
                break;
            }
        default:
            {
                cout<<"Please enter correct number.\n\n"<<endl;
            }
        }
    }
    out:
    return 0;
}
